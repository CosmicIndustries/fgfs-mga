#include "TrainingStatsModel.hxx"

#include <QDir>
#include <QDirIterator>
#include <QFileInfo>
#include <QHash>
#include <QMap>
#include <QPair>
#include <QVariantMap>
#include <algorithm>

#include <sqlite3.h>

namespace {
QString norm(QString s)
{
    s = s.toLower();
    QString out;
    out.reserve(s.size());
    for (const QChar c : s) {
        if (c.isLetterOrNumber()) out += c;
    }
    return out;
}

QString qident(QString s)
{
    s.replace('"', "\"\"");
    return QStringLiteral("\"") + s + QStringLiteral("\"");
}

QString cellText(sqlite3_stmt* stmt, int col)
{
    if (col < 0 || sqlite3_column_type(stmt, col) == SQLITE_NULL) return QString();
    const auto* p = sqlite3_column_text(stmt, col);
    return p ? QString::fromUtf8(reinterpret_cast<const char*>(p)) : QString();
}

double cellNumber(sqlite3_stmt* stmt, int col)
{
    if (col < 0 || sqlite3_column_type(stmt, col) == SQLITE_NULL) return 0.0;
    const int type = sqlite3_column_type(stmt, col);
    if (type == SQLITE_INTEGER || type == SQLITE_FLOAT) return sqlite3_column_double(stmt, col);
    bool ok = false;
    const double v = cellText(stmt, col).trimmed().toDouble(&ok);
    return ok ? v : 0.0;
}

bool cellFlag(sqlite3_stmt* stmt, int col)
{
    if (col < 0 || sqlite3_column_type(stmt, col) == SQLITE_NULL) return false;
    const QString s = cellText(stmt, col).trimmed().toLower();
    if (s == QStringLiteral("true") || s == QStringLiteral("yes")) return true;
    bool ok = false;
    const double n = s.toDouble(&ok);
    return ok && n != 0.0;
}

int findColumn(const QHash<QString, int>& columns, const QStringList& aliases)
{
    for (const QString& alias : aliases) {
        const auto it = columns.constFind(norm(alias));
        if (it != columns.constEnd()) return it.value();
    }
    return -1;
}

QString formatHours(double hours)
{
    const qlonglong minutes = qMax<qlonglong>(0, qRound64(hours * 60.0));
    return QStringLiteral("%1h %2m").arg(minutes / 60).arg(minutes % 60, 2, 10, QLatin1Char('0'));
}

QString findLogbook(QStringList* candidates)
{
    QStringList bases;
    const QString env = qEnvironmentVariable("FG_HOME").trimmed();
    if (!env.isEmpty()) bases << QDir::cleanPath(env);
    bases << QDir(QDir::homePath()).filePath(".fgfs");
    bases.removeDuplicates();

    const QString relative = "Export/Addons/org.flightgear.addons.logbook/logbook.sqlite";
    for (const QString& base : bases) {
        const QString p = QDir(base).filePath(relative);
        if (candidates) candidates->append(p);
        if (QFileInfo(p).isFile()) return p;
        const QString addons = QDir(base).filePath("Export/Addons");
        if (QFileInfo(addons).isDir()) {
            QDirIterator it(addons, QStringList() << "logbook.sqlite", QDir::Files, QDirIterator::Subdirectories);
            if (it.hasNext()) return it.next();
        }
    }
    return QString();
}

struct FlightRow {
    QVariantMap map;
    QString aircraft;
    double hours = 0.0;
};
}

TrainingStatsModel::TrainingStatsModel(QObject* parent) : QObject(parent)
{
    refresh();
}

void TrainingStatsModel::refresh()
{
    m_available = false;
    m_flightCount = 0;
    m_totalHours = m_dayHours = m_nightHours = m_instrumentHours = 0.0;
    m_landings = m_crashes = 0;
    m_distanceNm = m_fuelGallons = m_maxAltitudeFt = 0.0;
    m_recentFlights.clear();
    m_hoursByAircraft.clear();

    QStringList candidates;
    QString path = findLogbook(&candidates);
    if (path.isEmpty()) {
        m_databasePath = candidates.isEmpty() ? QString() : candidates.first();
        m_status = QStringLiteral("No FlightGear Logbook database found. Enable the Logbook add-on in Add-ons → Add-on Module folders, then complete a flight. The page will populate when logbook.sqlite is created.");
        emit changed();
        return;
    }
    m_databasePath = path;

    sqlite3* db = nullptr;
    const QByteArray utf8 = QFileInfo(path).absoluteFilePath().toUtf8();
    const int openRc = sqlite3_open_v2(utf8.constData(), &db,
                                      SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX, nullptr);
    if (openRc != SQLITE_OK) {
        m_status = QStringLiteral("Could not open the logbook read-only: %1")
                       .arg(db ? QString::fromUtf8(sqlite3_errmsg(db)) : QStringLiteral("SQLite open failed"));
        if (db) sqlite3_close(db);
        emit changed();
        return;
    }
    sqlite3_busy_timeout(db, 800);

    QStringList tables;
    sqlite3_stmt* tableStmt = nullptr;
    if (sqlite3_prepare_v2(db, "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'", -1, &tableStmt, nullptr) == SQLITE_OK) {
        while (sqlite3_step(tableStmt) == SQLITE_ROW) tables << cellText(tableStmt, 0);
    }
    if (tableStmt) sqlite3_finalize(tableStmt);

    QString table;
    QHash<QString, QHash<QString, int>> columnCache;
    for (const QString& name : tables) {
        QHash<QString, int> cols;
        sqlite3_stmt* info = nullptr;
        const QByteArray pragma = QStringLiteral("PRAGMA table_info(%1)").arg(qident(name)).toUtf8();
        if (sqlite3_prepare_v2(db, pragma.constData(), -1, &info, nullptr) == SQLITE_OK) {
            int i = 0;
            while (sqlite3_step(info) == SQLITE_ROW) {
                cols.insert(norm(cellText(info, 1)), i++);
            }
        }
        if (info) sqlite3_finalize(info);
        columnCache.insert(name, cols);
        if (norm(name) == QStringLiteral("logbook")) table = name;
    }
    if (table.isEmpty()) {
        for (const QString& name : tables) {
            const auto cols = columnCache.value(name);
            if (findColumn(cols, {"aircraft"}) >= 0 &&
                (findColumn(cols, {"duration", "flightDuration"}) >= 0 ||
                 (findColumn(cols, {"day"}) >= 0 && findColumn(cols, {"night"}) >= 0))) {
                table = name;
                break;
            }
        }
    }
    if (table.isEmpty()) {
        m_status = QStringLiteral("A logbook database was found, but no compatible flight table was detected.");
        sqlite3_close(db);
        emit changed();
        return;
    }

    QHash<QString, int> columns = columnCache.value(table);
    const int aircraftCol = findColumn(columns, {"aircraft"});
    const int variantCol = findColumn(columns, {"variant"});
    const int noteCol = findColumn(columns, {"note"});
    const int dateCol = findColumn(columns, {"realDate", "date", "datetime", "simLocalDate", "simUTCDate", "utcDate"});
    const int timeCol = findColumn(columns, {"realTime", "time", "simLocalTime", "simUTCTime", "utcTime"});
    const int fromCol = findColumn(columns, {"from", "departure", "departureAirport"});
    const int toCol = findColumn(columns, {"to", "destination", "arrivalAirport"});
    const int durationCol = findColumn(columns, {"duration", "flightDuration"});
    const int dayCol = findColumn(columns, {"day", "dayHours"});
    const int nightCol = findColumn(columns, {"night", "nightHours"});
    const int instrumentCol = findColumn(columns, {"instrument", "imc", "instrumentHours"});
    const int distanceCol = findColumn(columns, {"distance", "distanceNm"});
    const int fuelCol = findColumn(columns, {"fuel", "fuelGallons"});
    const int landingCol = findColumn(columns, {"landing", "landed"});
    const int crashCol = findColumn(columns, {"crash", "crashed"});
    const int altitudeCol = findColumn(columns, {"maxAlt", "maxAltitude", "maximumAltitude"});

    if (aircraftCol < 0 || (durationCol < 0 && dayCol < 0 && nightCol < 0)) {
        m_status = QStringLiteral("A logbook database was found, but its flight table is missing Aircraft or Duration fields.");
        sqlite3_close(db);
        emit changed();
        return;
    }

    const QByteArray query = QStringLiteral("SELECT rowid, * FROM %1 ORDER BY rowid DESC").arg(qident(table)).toUtf8();
    sqlite3_stmt* rows = nullptr;
    int offset = 1;
    int rc = sqlite3_prepare_v2(db, query.constData(), -1, &rows, nullptr);
    if (rc != SQLITE_OK) {
        const QByteArray fallback = QStringLiteral("SELECT * FROM %1").arg(qident(table)).toUtf8();
        if (sqlite3_prepare_v2(db, fallback.constData(), -1, &rows, nullptr) != SQLITE_OK) {
            m_status = QStringLiteral("Could not read the logbook table: %1").arg(QString::fromUtf8(sqlite3_errmsg(db)));
            sqlite3_close(db);
            emit changed();
            return;
        }
        offset = 0;
    }

    QMap<QString, QPair<double, int>> byAircraft;
    QVariantList recent;
    while ((rc = sqlite3_step(rows)) == SQLITE_ROW) {
        const auto textAt = [&](int col) { return cellText(rows, col < 0 ? -1 : col + offset); };
        const auto numberAt = [&](int col) { return cellNumber(rows, col < 0 ? -1 : col + offset); };
        const auto flagAt = [&](int col) { return cellFlag(rows, col < 0 ? -1 : col + offset); };
        const QString aircraft = textAt(aircraftCol);
        const QString variant = textAt(variantCol);
        const QString note = textAt(noteCol);
        const double day = numberAt(dayCol);
        const double night = numberAt(nightCol);
        const double duration = durationCol >= 0 ? numberAt(durationCol) : day + night;
        const double instrument = numberAt(instrumentCol);
        const double distance = numberAt(distanceCol);
        const double fuel = numberAt(fuelCol);
        const double altitude = numberAt(altitudeCol);
        const bool landed = flagAt(landingCol);
        const bool crashed = flagAt(crashCol);

        ++m_flightCount;
        m_totalHours += duration;
        m_dayHours += day;
        m_nightHours += night;
        m_instrumentHours += instrument;
        m_distanceNm += distance;
        m_fuelGallons += fuel;
        if (altitude > m_maxAltitudeFt) m_maxAltitudeFt = altitude;
        if (landed) ++m_landings;
        if (crashed) ++m_crashes;

        const QString group = aircraft.isEmpty() ? (variant.isEmpty() ? QStringLiteral("Unknown") : variant) : aircraft;
        auto accum = byAircraft.value(group, qMakePair(0.0, 0));
        accum.first += duration;
        accum.second += 1;
        byAircraft.insert(group, accum);

        if (recent.size() < 12) {
            QString date = textAt(dateCol);
            const QString time = textAt(timeCol);
            if (!time.isEmpty() && time != date) date += (date.isEmpty() ? QString() : QStringLiteral(" ")) + time;
            if (date.isEmpty()) date = QStringLiteral("Date not recorded");
            const QString visibleAircraft = !note.isEmpty() ? note :
                (!variant.isEmpty() && variant != aircraft ? variant : (aircraft.isEmpty() ? QStringLiteral("Unknown aircraft") : aircraft));
            const QString from = textAt(fromCol).isEmpty() ? QStringLiteral("—") : textAt(fromCol);
            const QString to = textAt(toCol).isEmpty() ? QStringLiteral("—") : textAt(toCol);
            QVariantMap entry;
            entry.insert(QStringLiteral("date"), date);
            entry.insert(QStringLiteral("aircraft"), visibleAircraft);
            entry.insert(QStringLiteral("route"), from + QStringLiteral(" → ") + to);
            entry.insert(QStringLiteral("duration"), formatHours(duration));
            entry.insert(QStringLiteral("hours"), duration);
            entry.insert(QStringLiteral("distance"), QString::number(distance, 'f', 1) + QStringLiteral(" nm"));
            entry.insert(QStringLiteral("result"), crashed ? QStringLiteral("Crash") : (landed ? QStringLiteral("Landed") : QStringLiteral("No landing logged")));
            recent.append(entry);
        }
    }
    sqlite3_finalize(rows);
    const QString readError = (rc == SQLITE_DONE) ? QString() : QString::fromUtf8(sqlite3_errmsg(db));
    sqlite3_close(db);

    if (!readError.isEmpty()) {
        m_status = QStringLiteral("Logbook query ended with an error: %1").arg(readError);
        emit changed();
        return;
    }

    m_recentFlights = recent;
    QList<QPair<QString, QPair<double, int>>> sortedHours;
    for (auto it = byAircraft.constBegin(); it != byAircraft.constEnd(); ++it)
        sortedHours.append(qMakePair(it.key(), it.value()));
    std::sort(sortedHours.begin(), sortedHours.end(), [](const auto& a, const auto& b) {
        return a.second.first > b.second.first;
    });
    for (const auto& item : sortedHours) {
        QVariantMap row;
        row.insert(QStringLiteral("aircraft"), item.first);
        row.insert(QStringLiteral("hours"), item.second.first);
        row.insert(QStringLiteral("hoursText"), formatHours(item.second.first));
        row.insert(QStringLiteral("flights"), item.second.second);
        m_hoursByAircraft.append(row);
    }

    m_available = true;
    m_status = m_flightCount == 0
        ? QStringLiteral("Logbook connected. No flights have been recorded yet.")
        : QStringLiteral("Loaded %1 logged flights from the FlightGear Logbook.").arg(m_flightCount);
    emit changed();
}
