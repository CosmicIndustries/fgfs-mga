#ifndef FG_GUI_TRAINING_STATS_MODEL_HXX
#define FG_GUI_TRAINING_STATS_MODEL_HXX

#include <QObject>
#include <QVariantList>
#include <QString>
#include <QStringList>

class TrainingStatsModel final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString status READ status NOTIFY changed)
    Q_PROPERTY(QString databasePath READ databasePath NOTIFY changed)
    Q_PROPERTY(bool available READ available NOTIFY changed)
    Q_PROPERTY(int flightCount READ flightCount NOTIFY changed)
    Q_PROPERTY(double totalHours READ totalHours NOTIFY changed)
    Q_PROPERTY(double dayHours READ dayHours NOTIFY changed)
    Q_PROPERTY(double nightHours READ nightHours NOTIFY changed)
    Q_PROPERTY(double instrumentHours READ instrumentHours NOTIFY changed)
    Q_PROPERTY(int landings READ landings NOTIFY changed)
    Q_PROPERTY(int crashes READ crashes NOTIFY changed)
    Q_PROPERTY(double distanceNm READ distanceNm NOTIFY changed)
    Q_PROPERTY(double fuelGallons READ fuelGallons NOTIFY changed)
    Q_PROPERTY(double maxAltitudeFt READ maxAltitudeFt NOTIFY changed)
    Q_PROPERTY(QVariantList recentFlights READ recentFlights NOTIFY changed)
    Q_PROPERTY(QVariantList hoursByAircraft READ hoursByAircraft NOTIFY changed)

public:
    explicit TrainingStatsModel(QObject* parent = nullptr);

    QString status() const { return m_status; }
    QString databasePath() const { return m_databasePath; }
    bool available() const { return m_available; }
    int flightCount() const { return m_flightCount; }
    double totalHours() const { return m_totalHours; }
    double dayHours() const { return m_dayHours; }
    double nightHours() const { return m_nightHours; }
    double instrumentHours() const { return m_instrumentHours; }
    int landings() const { return m_landings; }
    int crashes() const { return m_crashes; }
    double distanceNm() const { return m_distanceNm; }
    double fuelGallons() const { return m_fuelGallons; }
    double maxAltitudeFt() const { return m_maxAltitudeFt; }
    QVariantList recentFlights() const { return m_recentFlights; }
    QVariantList hoursByAircraft() const { return m_hoursByAircraft; }

    Q_INVOKABLE void refresh();

signals:
    void changed();

private:
    QString m_status;
    QString m_databasePath;
    bool m_available = false;
    int m_flightCount = 0;
    double m_totalHours = 0.0;
    double m_dayHours = 0.0;
    double m_nightHours = 0.0;
    double m_instrumentHours = 0.0;
    int m_landings = 0;
    int m_crashes = 0;
    double m_distanceNm = 0.0;
    double m_fuelGallons = 0.0;
    double m_maxAltitudeFt = 0.0;
    QVariantList m_recentFlights;
    QVariantList m_hoursByAircraft;
};

#endif
