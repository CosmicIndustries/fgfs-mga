// MGA pre-flight maths shared by the Summary, Settings and Location pages.
.pragma library

// PA-28-161 Warrior (2440 lb normal category). Arms from the POH weight & balance section.
var WARRIOR = {
    maxGross: 2440, maxBaggage: 200, usableFuelGal: 48,
    armFront: 80.5, armRear: 118.1, armFuel: 95.0, armBaggage: 142.8,
    fwdLimitAt: function(w) { return w <= 1950 ? 83.0 : 83.0 + (w - 1950) * (4.0 / 490.0); },
    aftLimit: 93.0
};

function num(v, dflt) {
    var n = parseFloat(v);
    return isNaN(n) ? dflt : n;
}

// p: {emptyLb, emptyArm, frontLb, rearLb, baggageLb, fuelGal}
function weightAndBalance(p) {
    var a = WARRIOR;
    if (!(p.emptyLb > 0) || !(p.emptyArm > 0))
        return { ok: false, known: false, text: "Enter your tail's empty weight and arm to check weight and balance." };
    var fuelLb = p.fuelGal * 6.0;
    var w = p.emptyLb + p.frontLb + p.rearLb + p.baggageLb + fuelLb;
    var m = p.emptyLb * p.emptyArm + p.frontLb * a.armFront + p.rearLb * a.armRear
          + p.baggageLb * a.armBaggage + fuelLb * a.armFuel;
    var cg = m / w;
    var fwd = a.fwdLimitAt(w);
    var problems = [];
    if (w > a.maxGross) problems.push("over max gross by " + Math.round(w - a.maxGross) + " lb");
    if (p.baggageLb > a.maxBaggage) problems.push("baggage over " + a.maxBaggage + " lb");
    if (cg < fwd) problems.push("CG forward of " + fwd.toFixed(1) + " in");
    if (cg > a.aftLimit) problems.push("CG aft of " + a.aftLimit.toFixed(1) + " in");
    // landing with the fuel burned (keep 45 min / about 6 gal)
    var landW = w - Math.max(0, fuelLb - 36);
    var landCg = (m - Math.max(0, fuelLb - 36) * a.armFuel) / landW;
    if (landCg < a.fwdLimitAt(landW) || landCg > a.aftLimit) problems.push("landing CG out of limits");
    var text = "Takeoff " + Math.round(w) + " lb, CG " + cg.toFixed(1) + " in"
             + (problems.length ? " · OUT OF LIMITS: " + problems.join(", ") : " · within limits");
    return { ok: problems.length === 0, known: true, gross: w, cg: cg, text: text };
}

// raw METAR -> {windDir (deg or -1 for VRB), windKt, gustKt, tempC, dewC, altimInHg}
function parseMetar(raw) {
    var r = { windDir: -1, windKt: 0, gustKt: 0, tempC: NaN, dewC: NaN, altimInHg: NaN };
    if (!raw) return r;
    var w = /\b(\d{3}|VRB)(\d{2,3})(G(\d{2,3}))?KT\b/.exec(raw);
    if (w) {
        r.windDir = w[1] === "VRB" ? -1 : parseInt(w[1], 10);
        r.windKt = parseInt(w[2], 10);
        r.gustKt = w[4] ? parseInt(w[4], 10) : 0;
    }
    var t = /\b(M?\d{2})\/(M?\d{2})?\b/.exec(raw);
    if (t) {
        r.tempC = parseInt(t[1].replace("M", "-"), 10);
        if (t[2]) r.dewC = parseInt(t[2].replace("M", "-"), 10);
    }
    var a = /\bA(\d{4})\b/.exec(raw);
    if (a) r.altimInHg = parseInt(a[1], 10) / 100.0;
    var q = /\bQ(\d{4})\b/.exec(raw);
    if (!a && q) r.altimInHg = parseInt(q[1], 10) / 33.8639;
    return r;
}

// pressure and density altitude in feet
function densityAltitude(elevFt, tempC, altimInHg) {
    if (isNaN(tempC) || isNaN(altimInHg)) return null;
    var pa = elevFt + (29.92 - altimInHg) * 1000.0;
    var isa = 15.0 - 2.0 * pa / 1000.0;
    return { pa: Math.round(pa), da: Math.round(pa + 120.0 * (tempC - isa)) };
}

// head (+) / tail (-) and cross wind components for a runway (true heading)
function windComponents(windDir, windKt, rwyHdg) {
    if (windDir < 0) return { head: 0, cross: windKt, variable: true };
    var d = (windDir - rwyHdg) * Math.PI / 180.0;
    return { head: Math.round(windKt * Math.cos(d)), cross: Math.round(Math.abs(windKt * Math.sin(d))), variable: false };
}

// sunrise / sunset (NOAA almanac method), as Date objects (UTC instants), or null in polar day/night
function sunTimes(lat, lon, date) {
    function rad(d) { return d * Math.PI / 180.0; }
    function deg(r) { return r * 180.0 / Math.PI; }
    var start = Date.UTC(date.getUTCFullYear(), 0, 0);
    var n = Math.floor((Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()) - start) / 86400000);
    var lngHour = lon / 15.0;
    function calc(rising) {
        var t = n + ((rising ? 6 : 18) - lngHour) / 24.0;
        var M = 0.9856 * t - 3.289;
        var L = (M + 1.916 * Math.sin(rad(M)) + 0.020 * Math.sin(rad(2 * M)) + 282.634 + 360.0) % 360.0;
        var RA = (deg(Math.atan(0.91764 * Math.tan(rad(L)))) + 360.0) % 360.0;
        RA = RA + (Math.floor(L / 90.0) * 90.0 - Math.floor(RA / 90.0) * 90.0);
        RA = RA / 15.0;
        var sinDec = 0.39782 * Math.sin(rad(L));
        var cosDec = Math.cos(Math.asin(sinDec));
        var cosH = (Math.cos(rad(90.833)) - sinDec * Math.sin(rad(lat))) / (cosDec * Math.cos(rad(lat)));
        if (cosH > 1 || cosH < -1) return null;
        var H = rising ? 360.0 - deg(Math.acos(cosH)) : deg(Math.acos(cosH));
        H = H / 15.0;
        var T = H + RA - 0.06571 * t - 6.622;
        var UT = ((T - lngHour) % 24.0 + 24.0) % 24.0;
        var d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
        return new Date(d.getTime() + UT * 3600000);
    }
    return { sunrise: calc(true), sunset: calc(false) };
}

// rough takeoff / landing distances from the POH's sea-level, standard-day, max-weight, no-wind figures:
// +10 % per 1000 ft density altitude (takeoff), +4 % (landing); weight squared (takeoff) / linear (landing);
// -10 % per 9 kt headwind; +10 % per 2 kt tailwind.
function distances(base, weight, da, headKt) {
    if (!(base.toRoll > 0) && !(base.ldgRoll > 0)) return null;
    var wr = weight > 0 ? weight / WARRIOR.maxGross : 1.0;
    var daK = Math.max(0, da || 0) / 1000.0;
    var wind = headKt >= 0 ? Math.max(0.5, 1.0 - 0.1 * headKt / 9.0) : 1.0 + 0.1 * (-headKt) / 2.0;
    function to(v) { return v > 0 ? Math.round(v * (1 + 0.10 * daK) * wr * wr * wind / 10) * 10 : 0; }
    function ld(v) { return v > 0 ? Math.round(v * (1 + 0.04 * daK) * wr * wind / 10) * 10 : 0; }
    return { toRoll: to(base.toRoll), to50: to(base.to50), ldgRoll: ld(base.ldgRoll), ldg50: ld(base.ldg50) };
}

// a METAR built from the launcher's weather choices
function buildMetar(o) {
    function pad(n, w) { var s = String(Math.round(Math.abs(n))); while (s.length < w) s = "0" + s; return s; }
    function temp(c) { return (c < 0 ? "M" : "") + pad(c, 2); }
    var now = new Date();
    var m = [o.station || "XXXX", pad(now.getUTCDate(), 2) + pad(now.getUTCHours(), 2) + pad(now.getUTCMinutes(), 2) + "Z"];
    if (!(o.windKt > 0)) m.push("00000KT");
    else m.push((o.windDir < 0 ? "VRB" : pad(o.windDir, 3)) + pad(o.windKt, 2) + (o.gustKt > o.windKt ? "G" + pad(o.gustKt, 2) : "") + "KT");
    m.push(o.visM >= 10000 || !(o.visM > 0) ? "9999" : pad(o.visM, 4));
    var layers = (o.layers || []).filter(function(l) { return l.cover && l.baseFt > 0; });
    layers.sort(function(a, b) { return a.baseFt - b.baseFt; });
    if (!layers.length) m.push("CLR");
    for (var i = 0; i < layers.length; i++) m.push(layers[i].cover + pad(layers[i].baseFt / 100, 3));
    m.push(temp(o.tempC) + "/" + temp(Math.min(o.dewC, o.tempC)));
    m.push("A" + pad(o.altimInHg * 100, 4));
    return m.join(" ");
}
