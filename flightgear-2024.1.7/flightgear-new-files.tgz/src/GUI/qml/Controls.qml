// MGA: Controls page. The controls window itself is fgfs-mga's Qt tool (fgfs-mga controls gui);
// this page opens it on the selected aircraft and shows what is saved and whether the sticks are ready.
import QtQuick 2.4
import QtQuick.Controls 2.2
import FlightGear 1.0

FocusScope {
    id: root

    property string aircraftId: ""
    property string checkText: qsTr("Checking the sticks…")
    property bool checkOk: false
    property string showText: ""
    property string openMessage: ""
    property double savedStamp: -1

    function refresh() {
        root.aircraftId = _launcher.selectedAircraftId()
        root.savedStamp = _launcher.controlsSavedStamp()
        root.checkText = qsTr("Checking the sticks…")
        _launcher.runControlsTool("check")
        _launcher.runControlsTool("show")
    }

    Component.onCompleted: refresh()
    onVisibleChanged: if (visible) refresh()

    Connections {
        target: _launcher
        function onControlsToolFinished(what, ok, text) {
            if (what === "check") {
                root.checkOk = ok
                root.checkText = text
            } else if (what === "show") {
                root.showText = text
            }
        }
        function onSelectedAircraftChanged() { root.aircraftId = _launcher.selectedAircraftId() }
    }

    // pick up a Save in the controls window without re-running the tools all the time
    Timer {
        interval: 2500
        repeat: true
        running: root.visible
        onTriggered: {
            var s = _launcher.controlsSavedStamp()
            if (s !== root.savedStamp) root.refresh()
        }
    }

    Rectangle {
        anchors.fill: parent
        color: Style.backgroundColor
    }

    Flickable {
        id: pageFlick
        anchors.fill: parent
        clip: true
        contentWidth: width
        contentHeight: Math.max(height + 1, pageColumn.implicitHeight + Style.margin * 2)
        flickableDirection: Flickable.VerticalFlick
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded; interactive: true }

        Column {
            id: pageColumn
            x: Style.inset
            y: Style.margin
            width: pageFlick.width - Style.inset * 2
            spacing: Style.margin * 2

            Text {
                text: qsTr("Controls")
                color: Style.baseTextColor
                font.pixelSize: Style.headingFontPixelSize
                font.bold: true
                width: parent.width
            }

            StyledText {
                width: parent.width
                wrapMode: Text.WordWrap
                text: qsTr("Set up the sticks, yoke, rudder and buttons before you fly: live axes and buttons, " +
                           "press-to-assign, reverse, dead zone and response curves, per aircraft or for all " +
                           "aircraft. Press Save in the controls window, then Fly: the next flight uses what you saved.")
            }

            Row {
                spacing: Style.margin
                Button {
                    text: root.aircraftId !== "" ? qsTr("Open controls for %1").arg(root.aircraftId)
                                                 : qsTr("Open controls")
                    onClicked: {
                        root.openMessage = _launcher.openControlsWindow()
                                ? qsTr("The controls window is opening beside this one.")
                                : qsTr("Couldn't start fgfs-mga controls. Is ~/.local/bin/fgfs-mga installed?")
                    }
                }
                Button {
                    text: qsTr("Check again")
                    onClicked: root.refresh()
                }
            }

            StyledText {
                visible: root.openMessage !== ""
                width: parent.width
                wrapMode: Text.WordWrap
                color: Style.themeContrastLinkColor
                text: root.openMessage
            }

            Rectangle {
                width: parent.width
                height: checkColumn.implicitHeight + Style.margin * 2
                color: Style.panelBackground
                radius: Style.roundRadius
                border.width: 1
                border.color: root.checkOk ? Style.minorFrameColor : Style.noteFrameColor

                Column {
                    id: checkColumn
                    x: Style.margin
                    y: Style.margin
                    width: parent.width - Style.margin * 2
                    spacing: Style.margin / 2
                    Text {
                        text: root.checkOk ? qsTr("Before you fly: ready") : qsTr("Before you fly")
                        color: Style.baseTextColor
                        font.bold: true
                        font.pixelSize: Style.subHeadingFontPixelSize
                    }
                    StyledText {
                        width: parent.width
                        wrapMode: Text.WordWrap
                        text: root.checkText
                    }
                }
            }

            Rectangle {
                width: parent.width
                height: showColumn.implicitHeight + Style.margin * 2
                color: Style.panelBackground
                radius: Style.roundRadius
                border.width: 1
                border.color: Style.minorFrameColor

                Column {
                    id: showColumn
                    x: Style.margin
                    y: Style.margin
                    width: parent.width - Style.margin * 2
                    spacing: Style.margin / 2
                    Text {
                        text: qsTr("Saved bindings")
                        color: Style.baseTextColor
                        font.bold: true
                        font.pixelSize: Style.subHeadingFontPixelSize
                    }
                    Text {
                        width: parent.width
                        wrapMode: Text.WrapAnywhere
                        color: Style.baseTextColor
                        font.family: "monospace"
                        font.pixelSize: Style.baseFontPixelSize
                        text: root.showText !== "" ? root.showText : qsTr("Loading…")
                    }
                }
            }
        }
    }
}
