import QtQuick 2.4
import QtQuick.Controls 2.2
import FlightGear 1.0
import FlightGear.Launcher 1.0

FocusScope {
    id: root

    signal showSelectedLocation()
    signal showSelectedAircraft()

    property var stats: _launcher.trainingStatsModel
    property string pendingAirport: ""
    property string airportMessage: "Choose an airport to set the launch location."

    function formatHours(hours) {
        var totalMinutes = Math.max(0, Math.round(hours * 60))
        return Math.floor(totalMinutes / 60) + "h " + (totalMinutes % 60) + "m"
    }

    function metricTitle(i) {
        return ["Flights logged", "Air time", "Day time", "Night time", "Instrument", "Landings", "Crashes", "Distance", "Fuel burned", "Max altitude"][i]
    }

    function metricValue(i) {
        if (!stats.available) return "—"
        switch (i) {
        case 0: return String(stats.flightCount)
        case 1: return formatHours(stats.totalHours)
        case 2: return formatHours(stats.dayHours)
        case 3: return formatHours(stats.nightHours)
        case 4: return formatHours(stats.instrumentHours)
        case 5: return String(stats.landings)
        case 6: return String(stats.crashes)
        case 7: return stats.distanceNm.toFixed(1) + " nm"
        case 8: return stats.fuelGallons.toFixed(1) + " US gal"
        case 9: return Math.round(stats.maxAltitudeFt).toLocaleString() + " ft"
        }
        return "—"
    }

    function selectTrainingAirport(icao) {
        root.pendingAirport = icao
        root.airportMessage = "Looking up " + icao + "…"
        airportLookup.setSearch(icao, _launcher.aircraftType)
    }

    Component.onCompleted: stats.refresh()
    onVisibleChanged: if (visible) stats.refresh()

    Timer {
        interval: 60000
        repeat: true
        running: root.visible
        onTriggered: stats.refresh()
    }

    Positioned { id: selectedTrainingAirport }

    NavaidSearch {
        id: airportLookup
        airportsOnly: true
        maxResults: 20
        onSearchComplete: {
            if (root.pendingAirport === "") return
            var requested = root.pendingAirport
            if (exactMatch !== 0) {
                selectedTrainingAirport.guid = exactMatch
                _location.setBaseLocation(selectedTrainingAirport)
                _location.addToRecent(selectedTrainingAirport)
                _location.useActiveRunway = true
                root.airportMessage = requested + " selected. Review runway and parking in Location."
                root.pendingAirport = ""
                root.showSelectedLocation()
            } else {
                root.airportMessage = "No exact airport match for " + requested + ". Check scenery/airport data and try again."
                root.pendingAirport = ""
            }
        }
    }

    ListModel {
        id: trainingAirports
        ListElement { ident: "KEZM"; name: "Heart of Georgia Regional"; detail: "Eastman · local training area" }
        ListElement { ident: "KMAC"; name: "Macon Downtown"; detail: "Macon · local practice" }
        ListElement { ident: "KMCN"; name: "Middle Georgia Regional"; detail: "Macon · regional approaches" }
        ListElement { ident: "KBQK"; name: "Brunswick Golden Isles"; detail: "Brunswick · local practice" }
        ListElement { ident: "PAHO"; name: "Homer Airport"; detail: "Homer, Alaska · scenery/terrain validation" }
        ListElement { ident: "KSSI"; name: "Malcolm McKinnon Field"; detail: "St. Simons · island-area practice" }
        ListElement { ident: "KAYS"; name: "Waycross-Ware County"; detail: "Waycross · cross-country option" }
        ListElement { ident: "KVDI"; name: "Vidalia Regional"; detail: "Vidalia · cross-country option" }
        ListElement { ident: "KSAV"; name: "Savannah/Hilton Head International"; detail: "Savannah · towered-airport practice" }
        ListElement { ident: "KJAX"; name: "Jacksonville International"; detail: "Florida · towered-airport practice" }
        ListElement { ident: "KTLH"; name: "Tallahassee International"; detail: "Florida · cross-country option" }
        ListElement { ident: "KABY"; name: "Southwest Georgia Regional"; detail: "Albany · cross-country option" }
        ListElement { ident: "KPDK"; name: "DeKalb-Peachtree"; detail: "Atlanta area · busy-airspace practice" }
    }

    ListModel {
        id: trainingFleet
        ListElement { name: "Piper Warrior III"; spec: "PA-28-161 · piston single · fixed tricycle gear · 160 hp model class"; role: "Primary trainer; normal/cross-country procedures. MGA tail-specific avionics, empty weight, arms, usable fuel and performance must come from the current dispatch sheet and POH." }
        ListElement { name: "Piper Archer TX"; spec: "PA-28-181 · piston single · fixed tricycle gear · 180 hp model class"; role: "Primary/advanced trainer. Confirm the exact installed avionics and POH revision; do not assume a generic Warrior's performance or panel." }
        ListElement { name: "Piper Arrow III"; spec: "PA-28R-201 · complex piston single · retractable gear · constant-speed propeller · 200 hp model class"; role: "Complex-aircraft procedures, gear/propeller management and cross-country. Check actual gear warning, prop and avionics variant." }
        ListElement { name: "Piper Seminole"; spec: "PA-44-180 · twin-engine piston · retractable gear · nominal 180 hp per engine class"; role: "Multi-engine systems, performance, engine-out and Vmc training. Confirm exact counter-rotation/propeller and aircraft-specific operating procedures." }
        ListElement { name: "Citabria Aurora"; spec: "American Champion Citabria · 7ECA family candidate · tailwheel"; role: "Tailwheel handling and approved basic-aerobatic maneuvers. Citabria engine/power choices vary; use the actual MGA variant's POH, not a guessed horsepower value." }
        ListElement { name: "Super Decathlon"; spec: "American Champion 8KCAB · tandem-seat tailwheel aerobatic aircraft"; role: "Spin/unusual-attitude and aerobatic training reference. Match the correct model and FDM; do not substitute a Citabria or an AI-only model." }
        ListElement { name: "Guimbal Cabri G2"; spec: "Two-seat light piston helicopter · skid gear · enclosed tail rotor"; role: "Rotorcraft procedures and helicopter PPL reference. Use the Cabri flight manual; an R44 is not a valid systems substitute." }
        ListElement { name: "Robinson R44"; spec: "Four-seat piston helicopter · skid gear · model variant must be confirmed"; role: "Rotorcraft systems, performance and procedures. Confirm Raven/Raven II and the current aircraft flight manual/dispatch sheet before using performance numbers." }
    }

    Rectangle {
        anchors.fill: parent
        color: Style.backgroundColor
    }

    Flickable {
        id: pageFlick
        anchors.fill: parent
        clip: true
        contentWidth: width
        contentHeight: Math.max(height + 1, pageColumn.implicitHeight + Style.margin * 2)
        flickableDirection: Flickable.VerticalFlick
        interactive: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded; interactive: true }

        Column {
            id: pageColumn
            x: Style.inset
            y: Style.margin
            width: pageFlick.width - Style.inset * 2
            spacing: Style.margin

            Text {
                text: qsTr("Training log & progress")
                color: Style.baseTextColor
                font.pixelSize: Style.headingFontPixelSize
                font.bold: true
                width: parent.width
            }

            Text {
                width: parent.width
                text: qsTr("Recorded simulator air time, recent flights and training locations. These are simulator records, not certified flight time.")
                color: Style.disabledTextColor
                wrapMode: Text.WordWrap
                font.pixelSize: Style.baseFontPixelSize
            }

            Rectangle {
                width: parent.width
                height: statusColumn.implicitHeight + Style.margin * 2
                color: Style.backgroundColor
                border.width: 1
                border.color: Style.minorFrameColor
                radius: Style.roundRadius
                Column {
                    id: statusColumn
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: Style.margin
                    spacing: Style.margin / 2
                    Text {
                        width: parent.width
                        text: stats.status
                        color: Style.baseTextColor
                        wrapMode: Text.WordWrap
                        font.pixelSize: Style.baseFontPixelSize
                    }
                    Text {
                        visible: !stats.available
                        width: parent.width
                        text: qsTr("If Logbook is enabled, complete a flight that takes off and lands, then exit FlightGear normally and refresh. Parked or taxi-only time is not airborne time. No hours are estimated or invented when the database is missing.")
                        color: Style.disabledTextColor
                        wrapMode: Text.WordWrap
                        font.pixelSize: Style.baseFontPixelSize
                    }
                    Text {
                        visible: stats.databasePath.length > 0
                        width: parent.width
                        text: qsTr("Data file: %1").arg(stats.databasePath)
                        color: Style.disabledTextColor
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Math.max(10, Style.baseFontPixelSize - 2)
                    }
                    Row {
                        spacing: Style.margin
                        Rectangle {
                            width: Style.strutSize * 5
                            height: Style.strutSize * 1.3
                            radius: Style.roundRadius
                            color: Style.themeColor
                            Text { anchors.centerIn: parent; text: qsTr("Refresh stats"); color: "white"; font.pixelSize: Style.baseFontPixelSize }
                            MouseArea { anchors.fill: parent; onClicked: stats.refresh() }
                        }
                        Rectangle {
                            width: Style.strutSize * 5
                            height: Style.strutSize * 1.3
                            radius: Style.roundRadius
                            color: Style.backgroundColor
                            border.width: 1
                            border.color: Style.minorFrameColor
                            Text { anchors.centerIn: parent; text: qsTr("Choose aircraft"); color: Style.baseTextColor; font.pixelSize: Style.baseFontPixelSize }
                            MouseArea { anchors.fill: parent; onClicked: root.showSelectedAircraft() }
                        }
                    }
                }
            }

            Text {
                text: qsTr("Flight totals")
                color: Style.baseTextColor
                font.pixelSize: Style.headingFontPixelSize
                font.bold: true
            }

            Flow {
                id: metricsFlow
                width: parent.width
                spacing: Style.margin
                Repeater {
                    model: 10
                    delegate: Rectangle {
                        width: Math.max(148, Math.floor((metricsFlow.width - Style.margin * 3) / 4))
                        height: Math.max(76, Style.strutSize * 1.55)
                        radius: Style.roundRadius
                        color: Style.backgroundColor
                        border.width: 1
                        border.color: Style.minorFrameColor
                        Column {
                            anchors.fill: parent
                            anchors.margins: Style.margin
                            spacing: Style.margin / 3
                            Text {
                                width: parent.width
                                text: root.metricTitle(index)
                                color: Style.disabledTextColor
                                font.pixelSize: Style.baseFontPixelSize
                                elide: Text.ElideRight
                            }
                            Text {
                                width: parent.width
                                text: root.metricValue(index)
                                color: Style.baseTextColor
                                font.pixelSize: Style.headingFontPixelSize
                                font.bold: true
                                elide: Text.ElideRight
                            }
                        }
                    }
                }
            }

            Text {
                text: qsTr("Hours by aircraft")
                color: Style.baseTextColor
                font.pixelSize: Style.headingFontPixelSize
                font.bold: true
            }
            Text {
                visible: !stats.available || stats.hoursByAircraft.length === 0
                width: parent.width
                text: stats.available ? qsTr("No aircraft time has been recorded yet.") : qsTr("Available after the logbook database is created.")
                color: Style.disabledTextColor
                wrapMode: Text.WordWrap
                font.pixelSize: Style.baseFontPixelSize
            }
            Column {
                width: parent.width
                spacing: Style.margin / 2
                Repeater {
                    model: stats.hoursByAircraft
                    delegate: Row {
                        width: parent.width
                        spacing: Style.margin
                        Text { width: parent.width * 0.38; text: modelData.aircraft; color: Style.baseTextColor; elide: Text.ElideRight; font.pixelSize: Style.baseFontPixelSize }
                        Text { width: parent.width * 0.25; text: modelData.hoursText; color: Style.baseTextColor; font.pixelSize: Style.baseFontPixelSize }
                        Text { width: parent.width * 0.18; text: modelData.flights + qsTr(" flights"); color: Style.disabledTextColor; font.pixelSize: Style.baseFontPixelSize }
                    }
                }
            }

            Text {
                text: qsTr("Recent flights")
                color: Style.baseTextColor
                font.pixelSize: Style.headingFontPixelSize
                font.bold: true
            }
            Text {
                visible: stats.recentFlights.length === 0
                width: parent.width
                text: stats.available ? qsTr("No flights recorded yet.") : qsTr("Recent flights will appear here after logging is enabled.")
                color: Style.disabledTextColor
                wrapMode: Text.WordWrap
                font.pixelSize: Style.baseFontPixelSize
            }
            Column {
                width: parent.width
                spacing: 1
                Repeater {
                    model: stats.recentFlights
                    delegate: Rectangle {
                        id: recentRow
                        property var flight: modelData
                        width: parent.width
                        height: recentContent.implicitHeight + Style.margin
                        color: Style.backgroundColor
                        border.width: 1
                        border.color: Style.minorFrameColor
                        radius: Style.roundRadius
                        Row {
                            id: recentContent
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.margins: Style.margin
                            spacing: Style.margin
                            Column {
                                width: recentRow.width * 0.25
                                Text { width: parent.width; text: recentRow.flight.date; color: Style.disabledTextColor; font.pixelSize: Style.baseFontPixelSize - 1; elide: Text.ElideRight }
                                Text { width: parent.width; text: recentRow.flight.aircraft; color: Style.baseTextColor; font.pixelSize: Style.baseFontPixelSize; elide: Text.ElideRight }
                            }
                            Column {
                                width: recentRow.width * 0.29
                                Text { width: parent.width; text: recentRow.flight.route; color: Style.baseTextColor; font.pixelSize: Style.baseFontPixelSize; elide: Text.ElideRight }
                                Text { width: parent.width; text: recentRow.flight.result; color: Style.disabledTextColor; font.pixelSize: Style.baseFontPixelSize - 1; elide: Text.ElideRight }
                            }
                            Column {
                                width: recentRow.width * 0.16
                                Text { width: parent.width; text: recentRow.flight.duration; color: Style.baseTextColor; font.pixelSize: Style.baseFontPixelSize }
                                Text { width: parent.width; text: recentRow.flight.distance; color: Style.disabledTextColor; font.pixelSize: Style.baseFontPixelSize - 1 }
                            }
                        }
                    }
                }
            }

            Text {
                text: qsTr("Training airports")
                color: Style.baseTextColor
                font.pixelSize: Style.headingFontPixelSize
                font.bold: true
            }
            Text {
                width: parent.width
                text: qsTr("Select an airport to set it as the launch location, then inspect runway, parking and weather options in Location.")
                color: Style.disabledTextColor
                wrapMode: Text.WordWrap
                font.pixelSize: Style.baseFontPixelSize
            }
            Flow {
                width: parent.width
                spacing: Style.margin
                Repeater {
                    model: trainingAirports
                    delegate: Rectangle {
                        width: Math.max(176, Math.floor((parent.width - Style.margin * 2) / 3))
                        height: Style.strutSize * 3.2
                        radius: Style.roundRadius
                        color: Style.backgroundColor
                        border.width: 1
                        border.color: Style.minorFrameColor
                        Column {
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.margins: Style.margin
                            spacing: Style.margin / 3
                            Text { width: parent.width; text: ident + " · " + name; color: Style.baseTextColor; font.bold: true; font.pixelSize: Style.baseFontPixelSize; elide: Text.ElideRight }
                            Text { width: parent.width; text: detail; color: Style.disabledTextColor; font.pixelSize: Style.baseFontPixelSize - 1; elide: Text.ElideRight }
                        }
                        MouseArea { anchors.fill: parent; onClicked: root.selectTrainingAirport(ident) }
                    }
                }
            }
            Text {
                width: parent.width
                text: root.airportMessage
                color: Style.disabledTextColor
                wrapMode: Text.WordWrap
                font.pixelSize: Style.baseFontPixelSize
            }

            Text {
                text: qsTr("Training aircraft reference fleet")
                color: Style.baseTextColor
                font.pixelSize: Style.headingFontPixelSize
                font.bold: true
            }
            Text {
                width: parent.width
                text: qsTr("Reference fleet based on Middle Georgia State University’s published Knight Flight list. These entries are study references, not a claim that every exact aircraft is installed. Use Choose aircraft above to browse available models. If the official hangar is not configured, open Aircraft and use Browse / Add default hangar, or add the official catalog under Add-ons.")
                color: Style.disabledTextColor
                wrapMode: Text.WordWrap
                font.pixelSize: Style.baseFontPixelSize
            }
            Text {
                width: parent.width
                textFormat: Text.RichText
                color: Style.baseTextColor
                linkColor: Style.themeContrastLinkColor
                wrapMode: Text.WordWrap
                font.pixelSize: Style.baseFontPixelSize
                text: qsTr("Official MGA aircraft procedures & specs: <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/warrior.php'>Warrior III</a> · <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/archer.php'>Archer TX</a> · <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/arrow.php'>Arrow III</a> · <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/seminole.php'>Seminole</a> · <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/citabria.php'>Citabria</a> · <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/super-decathlon.php'>Super Decathlon</a> · <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/cabri-g2.php'>Cabri G2</a> · <a href='https://www.mga.edu/aviation/knight-flight/aircraft-information-procedures/r44.php'>R44</a>")
                onLinkActivated: function(link) { Qt.openUrlExternally(link); }
            }
            Column {
                width: parent.width
                spacing: Style.margin / 2
                Repeater {
                    model: trainingFleet
                    delegate: Rectangle {
                        id: fleetRow
                        width: parent.width
                        height: fleetContents.implicitHeight + Style.margin * 2
                        color: Style.backgroundColor
                        border.width: 1
                        border.color: Style.minorFrameColor
                        radius: Style.roundRadius
                        Row {
                            id: fleetContents
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.margins: Style.margin
                            Column {
                                width: fleetRow.width - Style.margin * 2
                                spacing: Style.margin / 3
                                Text {
                                    width: parent.width
                                    text: name + " · " + spec
                                    color: Style.baseTextColor
                                    font.bold: true
                                    font.pixelSize: Style.baseFontPixelSize
                                    wrapMode: Text.WordWrap
                                }
                                Text {
                                    width: parent.width
                                    text: role
                                    color: Style.disabledTextColor
                                    font.pixelSize: Style.baseFontPixelSize - 1
                                    wrapMode: Text.WordWrap
                                }
                            }
                        }
                    }
                }
            }

            Item { width: 1; height: Style.margin * 2 }
        }
    }
}
